export const environment = {
  production: true,
  apiUrl: 'https://your-deployed-backend.example.com'
};
